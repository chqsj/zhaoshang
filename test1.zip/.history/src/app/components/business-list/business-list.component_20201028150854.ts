import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-list',
  templateUrl: './business-list.component.html',
  styleUrls: ['./business-list.component.scss']
})
export class BusinessListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  onChange(result: Date): void {
    console.log('Selected Time: ', result);
  }

}
