import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {routers} from './routers'

const routes: Routes = [
  ...routers,
  {
    path:'',
    redirectTo:'dashboard',
    pathMatch:'full'
  },
  {
    path:'user',
    loadChildren:'./module/a/a.module.ts#AModule'
  },
  {
    path:'prod',
    loadChildren:'./module/b/b.module.ts#BModule'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
