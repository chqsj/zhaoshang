import { Component, OnInit } from '@angular/core';
import { listOfMapData } from './ss';

export interface TreeNodeInterface {
  key: string;
  desc: string;
  age?: number;
  level?: number;
  expand?: boolean;
  address?: string;
  children?: TreeNodeInterface[];
  parent?: TreeNodeInterface;
}

@Component({
  selector: 'app-business-list',
  templateUrl: './business-list.component.html',
  styleUrls: ['./business-list.component.scss'],
})
export class BusinessListComponent implements OnInit {
  public searchVAalue: string = '';
  public listOfMapData: TreeNodeInterface[];
  // public listOfMapData: TreeNodeInterface[] = [
  //   {
  //     key: `1`,
  //     name: 'John Brown sr.',
  //     age: 60,
  //     address: 'New York No. 1 Lake Park',
  //     children: [
  //       {
  //         key: `1-1`,
  //         name: 'John Brown',
  //         age: 42,
  //         address: 'New York No. 2 Lake Park'
  //       },
  //       {
  //         key: `1-2`,
  //         name: 'John Brown jr.',
  //         age: 30,
  //         address: 'New York No. 3 Lake Park',
  //         children: [
  //           {
  //             key: `1-2-1`,
  //             name: 'Jimmy Brown',
  //             age: 16,
  //             address: 'New York No. 3 Lake Park'
  //           }
  //         ]
  //       },
  //       {
  //         key: `1-3`,
  //         name: 'Jim Green sr.',
  //         age: 72,
  //         address: 'London No. 1 Lake Park',
  //         children: [
  //           {
  //             key: `1-3-1`,
  //             name: 'Jim Green',
  //             age: 42,
  //             address: 'London No. 2 Lake Park',
  //             children: [
  //               {
  //                 key: `1-3-1-1`,
  //                 name: 'Jim Green jr.',
  //                 age: 25,
  //                 address: 'London No. 3 Lake Park'
  //               },
  //               {
  //                 key: `1-3-1-2`,
  //                 name: 'Jimmy Green sr.',
  //                 age: 18,
  //                 address: 'London No. 4 Lake Park'
  //               }
  //             ]
  //           }
  //         ]
  //       }
  //     ]
  //   },
  //   {
  //     key: `2`,
  //     name: 'Joe Black',
  //     age: 32,
  //     address: 'Sidney No. 1 Lake Park'
  //   }
  // ];
  public mapOfExpandedData: { [key: string]: TreeNodeInterface[] } = {};
  public columns: any[] = [
    {
      title: '业务码和描述',
      width: 500,
    },
    {
      title: '架构图',
      width: 100,
    },
    {
      title: '趋势图',
      width: 100,
    },
    {
      title: '请求量',
      width: 100,
    },
    {
      title: '响应量',
      width: 100,
    },
    {
      title: '响应率',
      width: 100,
    },
    {
      title: '平均响应时间',
      width: 150,
    },
    {
      title: '最大响应时间',
      width: 150,
    },
    {
      title: '成功量',
      width: 100,
    },
    {
      title: '成功率',
      width: 100,
    },
    {
      title: '采样',
      width: 100,
    },
    {
      title: '错误码',
      width: 300,
    },
  ];
  public pageData: any = {
    pageSize: 10,
    padeIndex: 1,
    total: listOfMapData.length,
  };
  constructor() {}

  ngOnInit(): void {
    this.listOfMapData = listOfMapData;
    this.listOfMapData.forEach((item) => {
      this.mapOfExpandedData[item.key] = this.convertTreeToList(item);
    });
  }

  onChange(result: Date): void {
    console.log('Selected Time: ', result);
  }

  onOk(result: Date | Date[] | null): void {
    console.log('onOk', result);
  }

  collapse(
    array: TreeNodeInterface[],
    data: TreeNodeInterface,
    $event: boolean
  ): void {
    if (!$event) {
      if (data.children) {
        data.children.forEach((d) => {
          const target = array.find((a) => a.key === d.key)!;
          target.expand = false;
          this.collapse(array, target, false);
        });
      } else {
        return;
      }
    }
  }

  convertTreeToList(root: TreeNodeInterface): TreeNodeInterface[] {
    const stack: TreeNodeInterface[] = [];
    const array: TreeNodeInterface[] = [];
    const hashMap = {};
    stack.push({ ...root, level: 0, expand: false });

    while (stack.length !== 0) {
      const node = stack.pop()!;
      this.visitNode(node, hashMap, array);
      if (node.children) {
        for (let i = node.children.length - 1; i >= 0; i--) {
          stack.push({
            ...node.children[i],
            level: node.level! + 1,
            expand: false,
            parent: node,
          });
        }
      }
    }

    return array;
  }

  visitNode(
    node: TreeNodeInterface,
    hashMap: { [key: string]: boolean },
    array: TreeNodeInterface[]
  ): void {
    if (!hashMap[node.key]) {
      hashMap[node.key] = true;
      array.push(node);
    }
  }

  // 页码改变的回调
  nzPageIndexChange(e) {
    console.log('页码改变的回调', e);
    this.pageData.pageIndex = e
    console.log(this.pageData.pageIndex);
    
  }
  // 每页条数改变的回调
  nzPageSizeChange(e) {
    console.log('每页条数改变的回调', e);
    this.pageData.pageSize = e
    console.log(this.pageData.pageSize);
  }
}
